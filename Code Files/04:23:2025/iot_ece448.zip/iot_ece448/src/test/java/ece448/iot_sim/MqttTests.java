package ece448.iot_sim;

import static org.junit.Assert.*;
import org.junit.Test;

import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MqttTests {

    // PlugSim Tests
    @Test
    public void testSwitchOn() {
        PlugSim plug = new PlugSim("testPlug");
        plug.switchOn();
        assertTrue(plug.isOn());
    }

    @Test
    public void testSwitchOff() {
        PlugSim plug = new PlugSim("testPlug");
        plug.switchOn();
        plug.switchOff();
        assertFalse(plug.isOn());
    }

    @Test
    public void testToggle() {
        PlugSim plug = new PlugSim("testPlug");
        plug.toggle();
        assertTrue(plug.isOn());
        plug.toggle();
        assertFalse(plug.isOn());
    }

    @Test
    public void testMeasurePower() {
        PlugSim plug = new PlugSim("testPlug");
        plug.switchOn();
        plug.measurePower();
        assertNotEquals(0.0, plug.getPower(), 0.001);
    }

    @Test
    public void testMeasurePowerWithDotInName() {
        PlugSim plug = new PlugSim("test.123");
        plug.switchOn();
        plug.measurePower();
        assertEquals(123.0, plug.getPower(), 0.001);
    }

    private static class TestObserver implements PlugSim.Observer {
        private String lastName;
        private String lastKey;
        private String lastValue;

        @Override
        public void update(String name, String key, String value) {
            this.lastName = name;
            this.lastKey = key;
            this.lastValue = value;
        }

        public boolean receivedStateUpdate(String state) {
            return "state".equals(lastKey) && state.equals(lastValue);
        }

        public boolean receivedPowerUpdate() {
            return "power".equals(lastKey);
        }
    }

    @Test
    public void testObserverNotificationOnSwitchOn() {
        PlugSim plug = new PlugSim("testPlug");
        TestObserver observer = new TestObserver();
        plug.addObserver(observer);
        plug.switchOn();
        assertTrue(observer.receivedStateUpdate("on"));
    }

    @Test
    public void testObserverNotificationOnPowerChange() {
        PlugSim plug = new PlugSim("testPlug");
        TestObserver observer = new TestObserver();
        plug.addObserver(observer);
        plug.switchOn();
        plug.measurePower();
        assertTrue(observer.receivedPowerUpdate());
    }

    // MqttCommands Tests
    @Test
    public void testHandleMessageOn() throws Exception {
        MqttCommands mqttCmd = new MqttCommands(new ArrayList<>(), "testPrefix");
        PlugSim plug = new PlugSim("testPlug");
        mqttCmd.addPlug(plug);
    
        String topic = "testPrefix/action/testPlug/on";
        MqttMessage msg = new MqttMessage("".getBytes());
    
        mqttCmd.handleMessage(topic, msg);
        assertTrue(plug.isOn());
    }


    @Test
    public void testHandleMessageOff() throws Exception {
        MqttCommands mqttCmd = new MqttCommands(new ArrayList<>(), "testPrefix");
        PlugSim plug = new PlugSim("testPlug");
        plug.switchOn();
        mqttCmd.addPlug(plug);
    
        String topic = "testPrefix/action/testPlug/off";
        MqttMessage msg = new MqttMessage("".getBytes());
    
        mqttCmd.handleMessage(topic, msg);
        assertFalse(plug.isOn());
    }

    @Test
    public void testHandleMessageToggle() throws Exception {
        MqttCommands mqttCmd = new MqttCommands(new ArrayList<>(), "testPrefix");
        PlugSim plug = new PlugSim("testPlug");
        mqttCmd.addPlug(plug);
    
        String topic = "testPrefix/action/testPlug/toggle";
        MqttMessage msg = new MqttMessage("".getBytes());
    
        mqttCmd.handleMessage(topic, msg);
        assertTrue(plug.isOn());
    }

    @Test
    public void testHandleMessageInvalidTopic() {
        MqttCommands mqttCmd = new MqttCommands(new ArrayList<>(), "");
        String topic = "invalidTopic";
        MqttMessage msg = new MqttMessage();
        
        mqttCmd.handleMessage(topic, msg);
        // Ensure no exceptions and plug remains unchanged
    }

    @Test
    public void testHandleMessageUnknownAction() {
        MqttCommands mqttCmd = new MqttCommands(new ArrayList<>(), "");
        PlugSim plug = new PlugSim("testPlug");
        mqttCmd.addPlug(plug);
        
        String topic = "testPrefix/action/testPlug/invalid";
        MqttMessage msg = new MqttMessage();
        
        mqttCmd.handleMessage(topic, msg);
        assertFalse(plug.isOn()); // No change as action is unknown
    }

    @Test
    public void testHandleMessageNonExistentPlug() {
        MqttCommands mqttCmd = new MqttCommands(new ArrayList<>(), "");
        String topic = "testPrefix/action/nonExistentPlug/on";
        MqttMessage msg = new MqttMessage();
        
        mqttCmd.handleMessage(topic, msg);
        // No plug exists, ensure no exceptions
    }

    // MqttUpdates Tests
    @Test
    public void testGetTopic() throws Exception {
        MqttClient mqttClient = new MqttClient("tcp://localhost:1883", "testClient");
        MqttUpdates mqttUpd = new MqttUpdates("testPrefix", mqttClient);
        String name = "testPlug";
        String key = "state";
        String expectedTopic = "testPrefix/update/testPlug/state";
        assertEquals(expectedTopic, mqttUpd.getTopic(name, key));
    }

    @Test
    public void testGetTopicWithMultiLevelPrefix() throws Exception {
        MqttClient mqttClient = new MqttClient("tcp://localhost:1883", "testClient");
        MqttUpdates mqttUpd = new MqttUpdates("a/b/c", mqttClient);
        String topic = mqttUpd.getTopic("plugName", "state");
        assertEquals("a/b/c/update/plugName/state", topic);
    }

    @Test
    public void testGetMessage() throws Exception {
        MqttClient mqttClient = new MqttClient("tcp://localhost:1883", "testClient");
        MqttUpdates mqttUpd = new MqttUpdates("testPrefix", mqttClient);
        String value = "on";
        MqttMessage msg = mqttUpd.getMessage(value);
        assertEquals("on", new String(msg.getPayload()));
        assertTrue(msg.isRetained());
    }

    @Test
    public void testPowerRandomWalk() {
        PlugSim plug = new PlugSim("testRandom");
        plug.switchOn();
        for (int i = 0; i < 10; i++) {
            plug.measurePower();
        }
        assertTrue(plug.getPower() >= 0);
    }

    @Test
    public void testMessageRetentionFlag() throws Exception {
        try (MqttClient client = new MqttClient("tcp://localhost:1883", "testClient")) {
            MqttUpdates mqttUpd = new MqttUpdates("prefix", client);
            MqttMessage msg = mqttUpd.getMessage("on");
            assertTrue(msg.isRetained());
        }
    }

    @Test
    public void testMultiLevelTopicPrefix() throws Exception {
        try (MqttClient client = new MqttClient("tcp://localhost:1883", "testClient")) {
            MqttUpdates mqttUpd = new MqttUpdates("a/b/c", client);
            String topic = mqttUpd.getTopic("plug", "state");
            assertEquals("a/b/c/update/plug/state", topic);
        }
    }

    @Test
    public void testPowerCalculationWithDottedName() {
        PlugSim plug = new PlugSim("test.250");
        plug.switchOn();
        plug.measurePower();
        assertEquals(250.0, plug.getPower(), 0.001);
    }

    @Test
    public void testConcurrentToggle() throws InterruptedException {
        PlugSim plug = new PlugSim("concurrentPlug");
        int numThreads = 10;
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);
    
        assertFalse(plug.isOn());
    
        for (int i = 0; i < numThreads; i++) {
            executor.submit(plug::toggle);
        }
        executor.shutdown();
        executor.awaitTermination(1, TimeUnit.SECONDS);
    
        assertFalse(plug.isOn());
    }

    @Test
    public void testMqttCommandsConstructor() {
        List<PlugSim> plugList = new ArrayList<>();
        plugList.add(new PlugSim("plug1"));
        plugList.add(new PlugSim("plug2"));
        MqttCommands mqttCmd = new MqttCommands(plugList, "testPrefix");
        assertEquals(2, mqttCmd.plugs.size());
        assertTrue(mqttCmd.plugs.containsKey("plug1"));
        assertTrue(mqttCmd.plugs.containsKey("plug2"));
    }

    @Test
    public void testGetTopic1() {
        MqttCommands mqttCmd = new MqttCommands(new ArrayList<>(), "testPrefix");
        String expectedTopic = "testPrefix/action/#";
        assertEquals(expectedTopic, mqttCmd.getTopic());
    }

    @Test
    public void testHandleMessageExceptionHandling() {
        MqttCommands mqttCmd = new MqttCommands(new ArrayList<>(), "testPrefix");
        String invalidTopic = null;
        MqttMessage msg = new MqttMessage();
        try {
            mqttCmd.handleMessage(invalidTopic, msg);
        } catch (Exception e) {
            fail("Exception should have been handled gracefully.");
        }
    }   

    @Test
    public void testPublishUpdateSuccess() throws Exception {
        MqttClient client = new MqttClient("tcp://localhost:1883", "testClient");
        client.connect();
        MqttUpdates mqttUpd = new MqttUpdates("testPrefix", client);
        String name = "testPlug";
        String key = "state";
        String value = "on";
        mqttUpd.publishUpdate(name, key, value);
        client.subscribe("testPrefix/update/testPlug/state", (topic, message) -> {
        assertEquals("on", new String(message.getPayload()));
        assertTrue(message.isRetained());
        client.disconnect();
        });
    }

    @Test
    public void testPublishUpdateExceptionHandling() throws Exception {
        MqttClient client = new MqttClient("tcp://localhost:1883", "testClient");
        client.connect();
        client.disconnect();
        MqttUpdates mqttUpd = new MqttUpdates("testPrefix", client);
        try {
            mqttUpd.publishUpdate("testPlug", "state", "on");
        } catch (Exception e) {
            fail("Exception should have been handled gracefully.");
        }
    }

}