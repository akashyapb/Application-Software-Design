package ece448.iot_sim;

import static org.junit.Assert.*;

import org.junit.Test;

public class PlugSimTests {

	@Test
	public void testInit() {
		PlugSim plug = new PlugSim("a");

		assertFalse(plug.isOn());
	}

	@Test
	public void testSwitchOn() {
		PlugSim plug = new PlugSim("a");

		plug.switchOn();

		assertTrue(plug.isOn());
	}

	@Test
    public void testGetName() {
        PlugSim plug = new PlugSim("test.100");
        assertEquals("test.100", plug.getName());
    }

	@Test
    public void testSwitchOffFromOn() {
        PlugSim plug = new PlugSim("a");
        plug.switchOn();
        plug.switchOff();
        assertFalse(plug.isOn());
    }

	@Test
    public void testMultipleSwitching() {
        PlugSim plug = new PlugSim("a");
        plug.switchOn();
        plug.switchOff();
        plug.switchOn();
        assertTrue(plug.isOn());
    }

	@Test
    public void testToggleFromOn() {
        PlugSim plug = new PlugSim("a");
        plug.switchOn();
        plug.toggle();
        assertFalse(plug.isOn());
    }

	@Test
    public void testToggleFromOff() {
        PlugSim plug = new PlugSim("a");
        plug.toggle();
        assertTrue(plug.isOn());
    }

	@Test
public void testPowerMeasurementWhenOn() {
    PlugSim plug = new PlugSim("test.500");
    plug.switchOn();
    plug.measurePower();
    assertEquals(500.0, plug.getPower(), 0.001);
    }

	@Test
public void testPowerMeasurementWhenOff() {
    PlugSim plug = new PlugSim("test.500");
    plug.measurePower();
    assertEquals(0.0, plug.getPower(), 0.001); 

	}

	@Test
public void testMultipleToggleAndPower() {
    PlugSim plug = new PlugSim("test.300");
    plug.toggle();
    plug.measurePower();
    assertEquals(300.0, plug.getPower(), 0.001);
    plug.toggle();
    plug.measurePower();
    assertEquals(0.0, plug.getPower(), 0.001);
    plug.toggle();
    plug.measurePower();
    assertEquals(300.0, plug.getPower(), 0.001);
	}

	@Test
public void testRandomWalkLowPower() {
    PlugSim plug = new PlugSim("a");  
    plug.switchOn();
    plug.updatePower(50);  
    double initialPower = plug.getPower();
    plug.measurePower();
    double newPower = plug.getPower();
    assertTrue(newPower > initialPower);  
    assertTrue(newPower <= initialPower + 100);  
}

@Test
public void testRandomWalkHighPower() {
    PlugSim plug = new PlugSim("a");
    plug.switchOn();
    plug.updatePower(350);  
    double initialPower = plug.getPower();
    plug.measurePower();
    double newPower = plug.getPower();
    assertTrue(newPower < initialPower);  
    assertTrue(newPower >= initialPower - 100);  
}

@Test
public void testRandomWalkMediumPower() {
    PlugSim plug = new PlugSim("a");
    plug.switchOn();
    plug.updatePower(200);  
    double initialPower = plug.getPower();
    plug.measurePower();
    double newPower = plug.getPower();
    assertTrue(Math.abs(newPower - initialPower) <= 20);  
}

}
