package ece448.iot_sim;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class HTTPCommandsTests {
    
    private HTTPCommands httpCommands;
    private PlugSim plug1;
    private PlugSim plug2;
    private PlugSim plugWithSpecialChar;
    
    @Before
    public void setUp() {
        plug1 = new PlugSim("plug1");
        plug2 = new PlugSim("plug2");
        plugWithSpecialChar = new PlugSim("zzzz.789");
        
        List<PlugSim> plugs = new ArrayList<>();
        plugs.add(plug1);
        plugs.add(plug2);
        plugs.add(plugWithSpecialChar);
        
        httpCommands = new HTTPCommands(plugs);
    }

    @Test
    public void testPlugReportDisplay() {
        String response = httpCommands.handleGet("/plug1", new HashMap<>());
        
        assertTrue(response.contains("plug1"));
        assertTrue(response.contains("plug1 is off"));
        assertTrue(response.contains("Power reading is 0.000"));
        assertTrue(response.contains("action=on"));
        assertTrue(response.contains("action=off"));
        assertTrue(response.contains("action=toggle"));
    }

    @Test
    public void testSwitchOnAction() {
        Map<String, String> params = new HashMap<>();
        params.put("action", "on");
        String response = httpCommands.handleGet("/plug1", params);
        
        assertTrue(response.contains("plug1 is on"));
        assertTrue(plug1.isOn());
        
        String checkResponse = httpCommands.handleGet("/plug1", new HashMap<>());
        assertTrue(checkResponse.contains("plug1 is on"));
    }

    @Test
    public void testSwitchOffAction() {
        
        plug1.switchOn();
       
        Map<String, String> params = new HashMap<>();
        params.put("action", "off");
        String response = httpCommands.handleGet("/plug1", params);
        
        assertTrue(response.contains("plug1 is off"));
        assertFalse(plug1.isOn());
       
        String checkResponse = httpCommands.handleGet("/plug1", new HashMap<>());
        assertTrue(checkResponse.contains("plug1 is off"));
    }

    @Test
    public void testToggleActionOffToOn() {
        
        plug1.switchOff();
      
        Map<String, String> params = new HashMap<>();
        params.put("action", "toggle");
        String response = httpCommands.handleGet("/plug1", params);
        
        assertTrue(response.contains("plug1 is on"));
        assertTrue(plug1.isOn());
    }

    @Test
    public void testToggleActionOnToOff() {
       
        plug1.switchOn();
       
        Map<String, String> params = new HashMap<>();
        params.put("action", "toggle");
        String response = httpCommands.handleGet("/plug1", params);
        
        assertTrue(response.contains("plug1 is off"));
        assertFalse(plug1.isOn());
    }

    @Test
    public void testPowerReadingUpdate() {
     
        plugWithSpecialChar.switchOn();
        plugWithSpecialChar.updatePower(789.0);
        
        String response = httpCommands.handleGet("/zzzz.789", new HashMap<>());
        assertTrue(response.contains("Power reading is 789.000"));
    }

    @Test
    public void testMultiplePlugsIndependence() {
        
        plug1.switchOn();
        plug2.switchOff();
        
        Map<String, String> params = new HashMap<>();
        params.put("action", "toggle");
        httpCommands.handleGet("/plug1", params);
     
        assertFalse(plug1.isOn());
        
        assertFalse(plug2.isOn());
        
        String plug2Response = httpCommands.handleGet("/plug2", new HashMap<>());
        assertTrue(plug2Response.contains("plug2 is off"));
    }

    @Test
    public void testSpecialCharactersInPlugNames() {
        
        String initialResponse = httpCommands.handleGet("/zzzz.789", new HashMap<>());
        assertTrue(initialResponse.contains("zzzz.789"));
       
        Map<String, String> params = new HashMap<>();
        params.put("action", "on");
        String updatedResponse = httpCommands.handleGet("/zzzz.789", params);
        
        assertTrue(updatedResponse.contains("zzzz.789 is on"));
        assertTrue(plugWithSpecialChar.isOn());
    }

    @Test
    public void testInvalidActionParameter() {
        
        Map<String, String> params = new HashMap<>();
        params.put("action", "invalid");
        String response = httpCommands.handleGet("/plug1", params);
        
        assertTrue(response.contains("plug1 is off"));
        assertFalse(plug1.isOn());
    }

    @Test
    public void testConcurrentActions() {
        
        Map<String, String> onParams = new HashMap<>();
        onParams.put("action", "on");
        httpCommands.handleGet("/plug1", onParams);
        assertTrue(plug1.isOn());
        
        Map<String, String> offParams = new HashMap<>();
        offParams.put("action", "off");
        httpCommands.handleGet("/plug1", offParams);
        assertFalse(plug1.isOn());
        
        Map<String, String> onAgainParams = new HashMap<>();
        onAgainParams.put("action", "on");
        String finalResponse = httpCommands.handleGet("/plug1", onAgainParams);
        
        assertTrue(finalResponse.contains("plug1 is on"));
        assertTrue(plug1.isOn());
    }
    
    @Test
    public void testListPlugs() {
   
        String response = httpCommands.handleGet("/", new HashMap<>());
        
        assertTrue(response.contains("href='/plug1'"));
        assertTrue(response.contains("href='/plug2'"));
        assertTrue(response.contains("href='/zzzz.789'"));
    }
    
    @Test
    public void testNonExistentPlug() {
        
        String response = httpCommands.handleGet("/nonexistent", new HashMap<>());
        
        assertNull(response);
    }
}