package ece448.iot_hub;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class PlugsResource {
    private final PlugsModel plugsModel;
    private static final Logger logger = LoggerFactory.getLogger(PlugsResource.class);

    public PlugsResource(PlugsModel plugsModel) {
        this.plugsModel = plugsModel;
    }

    @GetMapping("/api/plugs")
    public List<Map<String, Object>> getAllPlugs() {
        List<Map<String, Object>> result = new ArrayList<>();
        
        Map<String, PlugsModel.Plug> allPlugs = plugsModel.getAllPlugs();
        for (String plugName : allPlugs.keySet()) {
            result.add(convertPlugToMap(allPlugs.get(plugName)));
        }
        
        logger.debug("getAllPlugs: returning {} plugs", result.size());
        return result;
    }

    @GetMapping("/api/plugs/{plugName:.+}")
    public Map<String, Object> getPlug(
        @PathVariable("plugName") String plugName,
        @RequestParam(value = "action", required = false) String action) {
        
        if (action != null) {
            if (action.equals("on") || action.equals("off") || action.equals("toggle")) {
                logger.info("Controlling plug {}: action={}", plugName, action);
                plugsModel.publishAction(plugName, action);
            } else {
                logger.warn("Invalid action for plug {}: {}", plugName, action);
            }
        }
        
        // Get the latest state
        String state = plugsModel.getPlugState(plugName);
        String power = plugsModel.getPlugPower(plugName);
        
        // Create and return the response
        Map<String, Object> result = new HashMap<>();
        result.put("name", plugName);
        result.put("state", state);
        
        try {
            result.put("power", Integer.parseInt(power));
        } catch (NumberFormatException e) {
            result.put("power", 0);
        }
        
        logger.debug("getPlug {}: state={}, power={}", plugName, state, power);
        return result;
    }
    
    private Map<String, Object> convertPlugToMap(PlugsModel.Plug plug) {
        Map<String, Object> map = new HashMap<>();
        map.put("name", plug.getName());
        map.put("state", plug.getState());
        
        try {
            map.put("power", Integer.parseInt(plug.getPower()));
        } catch (NumberFormatException e) {
            map.put("power", 0);
        }
        
        return map;
    }
}