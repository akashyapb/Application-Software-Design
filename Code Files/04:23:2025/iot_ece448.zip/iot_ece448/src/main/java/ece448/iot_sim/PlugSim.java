package ece448.iot_sim;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.ArrayList;

/**
 * Simulate a smart plug with power monitoring.
 */
public class PlugSim {

	private final String name;
	private boolean on = false;
	private double power = 0; // in watts

	public PlugSim(String name) {
		this.name = name;
	}

	/**
	 * No need to synchronize if read a final field.
	 */
	public String getName() {
		return name;
	}

	public static interface Observer {
		void update (String name, String key, String value);		
	}

	private final List<Observer> observers = new ArrayList<>();

	public void addObserver(Observer observer) {
		observers.add(observer);
		observer.update(name, "state", on ? "on" : "off" );
		observer.update(name, "power", String.format("%.3f", power));
	}
	/**
	 * Switch the plug on.
	 */
	synchronized public void switchOn() {
		// P1: add your code here
		on = true;
		measurePower();
		notifyObservers("state", "on");
	}

	/**
	 * Switch the plug off.
	 */
	synchronized public void switchOff() {
		// P1: add your code here
		on = false;
		notifyObservers("state", "off");
	}

	/**
	 * Toggle the plug.
	 */
	synchronized public void toggle() {
		// P1: add your code here
		on = !on;
		notifyObservers("state", on ? "on" : "off");
		if(on) {
			measurePower();
			notifyObservers("power", String.format("%.3f", power));
		}
	}

	/**
	 * Measure power.
	 */
	synchronized public void measurePower() {
		if (!on) {
			updatePower(0);
			return;
		}

		// a trick to help testing
		if (name.indexOf(".") != -1)
		{
			updatePower(Integer.parseInt(name.split("\\.")[1]));
		}
		// do some random walk
		else if (power < 100)
		{
			updatePower(power + Math.random() * 100);
		}
		else if (power > 300)
		{
			updatePower(power - Math.random() * 100);
		}
		else
		{
			updatePower(power + Math.random() * 40 - 20);
		}
		notifyObservers("power", String.format("%.3f", power));
	}

	private void notifyObservers(String key, String value) { 
		for (Observer observer : observers) {
			observer.update(name, key, value);
		}
	}

	protected void updatePower(double p) {
		power = p;
		logger.debug("Plug {}: power {}", name, power);
	}

	/**
	 * Getter: current state
	 */
	synchronized public boolean isOn() {
		return on;
	}

	/**
	 * Getter: last power reading
	 */
	synchronized public double getPower() {
		return power;
	}

	private static final Logger logger = LoggerFactory.getLogger(PlugSim.class);


}
