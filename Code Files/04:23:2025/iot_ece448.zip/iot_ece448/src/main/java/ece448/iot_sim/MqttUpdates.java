package ece448.iot_sim;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MqttUpdates {
    private final String topicPrefix;
    private final MqttClient mqttClient;
    private static final Logger logger = LoggerFactory.getLogger(MqttUpdates.class);

    public MqttUpdates(String topicPrefix, MqttClient mqttClient) {
        this.topicPrefix = topicPrefix;
        this.mqttClient = mqttClient;
    }

    // Generating topic for given plug and key
    public String getTopic(String name, String key) {
        return topicPrefix + "/update/" + name + "/" + key;
    }

    // Generating MQTT message for given value
    public MqttMessage getMessage(String value) {
        MqttMessage msg = new MqttMessage(value.getBytes());
        msg.setRetained(true);
        return msg;
    }

    // Publishing update to the MQTT broker
    public void publishUpdate(String name, String key, String value) {
        try {
            String topic = getTopic(name, key);
            MqttMessage msg = getMessage(value);
            mqttClient.publish(topic, msg);
            logger.info("Published update: {} -> {}", topic, value);
        } catch (Exception e) {
            logger.error("Failed to publish update for {} {} {}", name, key, value, e);
        }
    }
}
