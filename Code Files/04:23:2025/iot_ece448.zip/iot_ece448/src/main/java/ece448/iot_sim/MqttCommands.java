package ece448.iot_sim;

import java.util.List;
import java.util.TreeMap;

import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MqttCommands {
    protected final TreeMap<String, PlugSim> plugs;
    private final String topicPrefix;
    private static final Logger logger = LoggerFactory.getLogger(MqttCommands.class);

    public MqttCommands(List<PlugSim> plugs, String topicPrefix) {
        this.plugs = new TreeMap<>();
        for (PlugSim plug : plugs) {
            this.plugs.put(plug.getName(), plug);
        }
        this.topicPrefix = topicPrefix;
    }

    public String getTopic() {
        return topicPrefix + "/action/#";
    }

    // Handling incoming MQTT messages
    public void handleMessage(String topic, MqttMessage message) {
        try {
            String[] parts = topic.split("/");
            if (parts.length < 2) {
                logger.warn("Invalid topic format: {}", topic);
                return;
            }

            String plugName = parts[parts.length-2];
        String action = parts[parts.length-1]; 

        PlugSim plug = plugs.get(plugName);
        if (plug != null) {
            switch (action) {
                case "on":
                    plug.switchOn();
                    break;
                case "off":
                    plug.switchOff();
                    break;
                case "toggle":
                    plug.toggle();
                    break;
                default:
                    logger.warn("Unknown action: {}", action);
            }
        }
    } catch (Exception e) {
        logger.error("Error handling MQTT message: {}", e.getMessage(), e);
        }
    }
    public void addPlug(PlugSim plug) {
        plugs.put(plug.getName(), plug);
    }
}
