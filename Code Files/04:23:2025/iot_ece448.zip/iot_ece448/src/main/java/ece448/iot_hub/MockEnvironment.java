package ece448.iot_hub;

import org.springframework.core.env.Environment;
import java.util.HashMap;
import java.util.Map;

public class MockEnvironment implements Environment {
   private final Map<String, String> properties = new HashMap<>();

   @Override
   public boolean containsProperty(String key) {
       return properties.containsKey(key);
   }

   @Override
   public String getProperty(String key) {
       return properties.get(key);
   }

   @Override
   public String getProperty(String key, String defaultValue) {
       return containsProperty(key) ? getProperty(key) : defaultValue;
   }

   public void setProperty(String key, Object value) {
       properties.put(key, String.valueOf(value));
   }

   public void put(String key, Object value) {
       setProperty(key, value);
   }

   @Override
   public <T> T getProperty(String key, Class<T> targetType) {
       throw new UnsupportedOperationException("Unimplemented method 'getProperty'");
   }

   @Override
   public <T> T getProperty(String key, Class<T> targetType, T defaultValue) {
       throw new UnsupportedOperationException("Unimplemented method 'getProperty'");
   }

   @Override
   public <T> Class<T> getPropertyAsClass(String key, Class<T> targetType) {
       throw new UnsupportedOperationException("Unimplemented method 'getPropertyAsClass'");
   }

   @Override
   public String getRequiredProperty(String key) throws IllegalStateException {
       throw new UnsupportedOperationException("Unimplemented method 'getRequiredProperty'");
   }

   @Override
   public <T> T getRequiredProperty(String key, Class<T> targetType) throws IllegalStateException {
       throw new UnsupportedOperationException("Unimplemented method 'getRequiredProperty'");
   }

   @Override
   public String resolvePlaceholders(String text) {
       throw new UnsupportedOperationException("Unimplemented method 'resolvePlaceholders'");
   }

   @Override
   public String resolveRequiredPlaceholders(String text) throws IllegalArgumentException {
       throw new UnsupportedOperationException("Unimplemented method 'resolveRequiredPlaceholders'");
   }

   @Override
   public String[] getActiveProfiles() {
       throw new UnsupportedOperationException("Unimplemented method 'getActiveProfiles'");
   }

   @Override
   public String[] getDefaultProfiles() {
       throw new UnsupportedOperationException("Unimplemented method 'getDefaultProfiles'");
   }

   @Override
   public boolean acceptsProfiles(String... profiles) {
       throw new UnsupportedOperationException("Unimplemented method 'acceptsProfiles'");
   }
}

