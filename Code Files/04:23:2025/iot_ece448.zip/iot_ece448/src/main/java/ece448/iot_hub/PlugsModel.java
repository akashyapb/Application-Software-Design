package ece448.iot_hub;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PreDestroy;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PlugsModel {

    private final ConcurrentHashMap<String, Plug> plugs = new ConcurrentHashMap<>();
    private final MqttController mqtt;
    private static final Logger logger = LoggerFactory.getLogger(PlugsModel.class);

    public PlugsModel(
        @Value("${mqtt.broker}") String broker,
        @Value("${mqtt.clientId}") String clientId,
        @Value("${mqtt.topicPrefix}") String topicPrefix
    ) throws Exception {
        // Prepare persistence directory for MQTT
        String persistenceDir = System.getProperty("java.io.tmpdir") + "/mqtt_persistence";
        new File(persistenceDir).mkdirs();

        // Initialize MQTT controller and subscribe for updates
        this.mqtt = new MqttController(broker, clientId, topicPrefix, persistenceDir);
        mqtt.setUpdateCallback((name, state, power) -> {
            updatePlug(name, state, power);
            logger.debug("Updated plug {}: state={}, power={}", name, state, power);
        });
        mqtt.start();
    }

    @PreDestroy
    public void close() {
        try {
            mqtt.close();
        } catch (Exception e) {
            logger.warn("Error closing MQTT controller", e);
        }
    }

    /**
     * Return the list of known plug names.
     */
    public List<String> getPlugs() {
        return new ArrayList<>(plugs.keySet());
    }

    /**
     * Return a map of all plugs to their latest state/power.
     */
    public Map<String, Plug> getAllPlugs() {
        // Ensure any pending updates are applied
        mqtt.refresh();
        return new HashMap<>(plugs);
    }

    /**
     * Get state: "on" or "off".
     */
    public String getPlugState(String name) {
        Plug p = plugs.get(name);
        return p != null ? p.getState() : "off";
    }

    /**
     * Get power reading as string (e.g., "0", "666.000").
     */
    public String getPlugPower(String name) {
        Plug p = plugs.get(name);
        return p != null ? p.getPower() : "0";
    }

    /**
     * Publish an action and update local state immediately.
     */
    public void publishAction(String name, String action) {
        mqtt.publishAction(name, action);
        // Locally reflect the change without waiting for MQTT
        String current = getPlugState(name);
        String next = current;
        if ("on".equals(action))       next = "on";
        else if ("off".equals(action)) next = "off";
        else if ("toggle".equals(action)) next = "on".equals(current) ? "off" : "on";
        if (!next.equals(current)) {
            updatePlug(name, next, getPlugPower(name));
        }
    }

    private void updatePlug(String name, String state, String power) {
        if (state != null && power != null) {
            plugs.put(name, new Plug(name, state, power));
        }
    }

    public static class Plug {
        private final String name;
        private final String state;
        private final String power;

        public Plug(String name, String state, String power) {
            this.name = name;
            this.state = state;
            this.power = power;
        }

        public String getName() { return name; }
        public String getState() { return state; }
        public String getPower() { return power; }
    }

    private static class MqttController {
        private final MqttClient client;
        private final String topicPrefix;
        private UpdateCallback callback;
        private final ConcurrentHashMap<String, String> states = new ConcurrentHashMap<>();
        private final ConcurrentHashMap<String, String> powers = new ConcurrentHashMap<>();
        private static final Logger logger = LoggerFactory.getLogger(MqttController.class);

        public MqttController(String broker, String clientId, String topicPrefix, String persistenceDir) throws Exception {
            this.topicPrefix = topicPrefix;
            this.client = new MqttClient(broker, clientId, new MqttDefaultFilePersistence(persistenceDir));
        }

        public void setUpdateCallback(UpdateCallback cb) {
            this.callback = cb;
        }

        public void start() throws Exception {
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(true);
            client.connect(options);
            client.subscribe(topicPrefix + "/update/#", this::handleUpdate);
            logger.info("MQTT connected to {} with prefix {}", client.getServerURI(), topicPrefix);
        }

        public void close() throws Exception {
            if (client.isConnected()) {
                client.disconnect();
            }
        }

        public void publishAction(String name, String action) {
            String topic = topicPrefix + "/action/" + name + "/" + action;
            try {
                client.publish(topic, new MqttMessage());
            } catch (Exception e) {
                logger.error("Failed to publish action {} for {}", action, name, e);
            }
        }

        private void handleUpdate(String topic, MqttMessage msg) {
            String suffix = topic.substring(topicPrefix.length() + 1);
            String[] parts = suffix.split("/");
            if (parts.length == 3 && "update".equals(parts[0])) {
                String name  = parts[1];
                String type = parts[2];
                String payload = new String(msg.getPayload());
                if ("state".equals(type)) {
                    states.put(name, payload);
                } else if ("power".equals(type)) {
                    powers.put(name, payload);
                }
                if (callback != null && states.containsKey(name) && powers.containsKey(name)) {
                    callback.onUpdate(name, states.get(name), powers.get(name));
                }
            }
        }

        public void refresh() {
            states.forEach((name, s) -> {
                String p = powers.get(name);
                if (p != null && callback != null) {
                    callback.onUpdate(name, s, p);
                }
            });
        }

        @FunctionalInterface
        private interface UpdateCallback {
            void onUpdate(String name, String state, String power);
        }
    }
}